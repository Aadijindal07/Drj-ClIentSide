<?php
include_once'header.php';
include_once 'config.php';
?>
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-+animate text-center">
            <h1 class="mb-2 bread">Appointment</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="home.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Appointment <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
		

<!-- Navbar-->
<header class="header">
    <nav class="navbar navbar-expand-lg navbar-light py-3">
        <div class="container">
            <!-- Navbar Brand -->
            <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
</script>
           <a class="navbar-brand" style="  font-size: 65px;">Dr.<span>J</span></a>
        </div>
    </nav>
</header>


<div class="container">
    <div class="row py-5 mt-4 align-items-center">
        <!-- For Demo Purpose -->
        <div class="col-md-5 pr-lg-+5 mb-5 mb-md-0">
            <img src="images/img-02.png" width=700" alt="" class="img-fluid mb-3 d-none d-md-block">
            <h1><b>Appointment</b></h1>
            <p class="font-italic text-muted mb-0"><h4>Book appointment onlines</h4></p>
           
        </div>

        <!-- Registeration Form -->
        <div class="col-md-7 col-lg-6 ml-auto">
            <form action="" method="POST">
                <div class="row">

                    <!-- First Name -->
                    <div class="input-group col-lg-6 mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                              <img src="images/user.png" width="25">
                                
                            </span>
                        </div>
                        <input id="firstName" type="text" name="fn" placeholder="First Name" class="form-control bg-white border-left-0 border-md">
                    </div>

                    <!-- Last Name -->
                    <div class="input-group col-lg-6 mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                               <img src="images/user.png" width="25">
                            </span>
                        </div>
                        <input id="lastName" type="text" name="ln" placeholder="Last Name" class="form-control bg-white border-left-0 border-md">
                    </div>

                    <!-- Email Address -->
                    <div class="input-group col-lg-12 mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <img src="images/mail.png" width="25">
                            </span>
                        </div>
                        <input id="email" type="email" name="email" placeholder="Email Address" class="form-control bg-white border-left-0 border-md">
                    </div>

                    <!-- Phone Number -->
                    <div class="input-group col-lg-12 mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <img src="images/pho.png" width="25">
                            </span>
                        </div>
                        <select id="countryCode" name="countryCode" style="max-width: 80px" class="custom-select form-control bg-white border-left-0 border-md h-100 font-weight-bold text-muted">
                            <option value="">+91</option>
                           
                        </select>
                        <input id="phoneNumber" type="tel" name="phone" placeholder="Phone Number" class="form-control bg-white border-md border-left-0 pl-3">
                    </div>
 <div class="input-group col-lg-12 mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <img src="images/gen.png" width="25">
                            </span>
                        </div>
                        <input id="text" type="text" name="gen" placeholder="Gender" class="form-control bg-white border-left-0 border-md">
                    </div>

                     <div class="input-group col-lg-12 mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <img src="images/age.png" width="25">
                            </span>
                        </div>
                        <input id="text" type="text" name="age" placeholder="Age" class="form-control bg-white border-left-0 border-md">
                    </div>

 <div class="input-group col-lg-12 mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <img src="images/ba.png" width="25">
                            </span>
                        </div>
                         <input id="datepicker" type="text"  name="dob" placeholder="Date of Birth" class="form-control bg-white border-left-0 border-md">
                    </div>
                    <!-- Job -->


                    <!-- Password Confirmation -->
                    <div class="input-group col-lg-6 mb-4">
                        <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                            <img src="images/cal.png" width="25">
                            </span>
                        </div>

                       <input id="dateepicker" name="doa" type="text"placeholder="Date of Appointment" class="form-control bg-white border-left-0 border-md"autocomplete="off"months=2>
               
                            </span>
<script>
  var badDates;
    $.getJSON(function(json){badDates=json;});
 
    $('#dateepicker').datepicker({

minDate: 0,
            dateFormat: 'dd-mm-yy',
            inline: true,
            numberOfMonths: [1, 2],
 

// for sat, sun-beforeShowDay: $.datepicker.noWeekends
});


</script>
<?php

$db = mysqli_connect("localhost","root","","doctor");

if(!$db)
{
    die("Connection failed: " . mysqli_connect_error());
}

?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/js/bootstrap-datepicker.min.js"></script>
                    </div>
                    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/js/bootstrap-datepicker.min.js">
                      
                    </script>
   
                    


               <div class="input-group col-lg-6 mb-4">
                          <div class="input-group-prepend">
                            <span class="input-group-text bg-white px-4 border-md border-right-0">
                                <img src="images/time.png" width="25">
                            </span>
                        </div>
                        <select id="time" class="form-control custom-select bg-white border-left-0 border-md" name="time">
                            <option disabled selected>Timings</option>
                                <?php
      // Using database connection file here
        $records = mysqli_query($db, "SELECT * From timing ");  // Use select query here 

        while($data = mysqli_fetch_array($records))
        {
            echo "<option value='". $data['timing'] ."'>" .$data['timing'] ."</option>";  // displaying data in option menu
        } 
    ?>  >
                        </select>

                    </div>
                    </div>
                    <!-- Submit Button -->
                    <div class="form-group col-lg-12 mx-auto mb-0">
                       
                          <input type="Submit" class="btn btn-primary btn-block py-2" name="book" value="Book Appointment">
                      
                    </div>

                    <!-- Divider Text -->
                    <div class="form-group col-lg-12 mx-auto d-flex align-items-center my-4">
                        <div class="border-bottom w-100 ml-5"></div>
                      
                        <div class="border-bottom w-100 mr-5"></div>
                    </div>
  
                    <!-- Social Login -->
        

                </div>
            </form>
        </div>
    </div>
</div>
<?php 
if (isset($_POST['book'])) {
    $fn=$_POST['fn'];
    $ln=$_POST['ln'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $gen=$_POST['gen'];
    $age=$_POST['age'];
    $dob=date('Y-m-d', strtotime($_POST['dob']));
    $hospital=$_POST['hospital'];
    $department=$_POST['department'];
    $doctor=$_POST['doctor'];
   $doa=date('Y-m-d', strtotime($_POST['doa']));
    $time=$_POST['time'];

    $res=mysqli_query($db,"INSERT into appointment values('','$fn','$ln','$email','$phone',
        '$gen','$age','$dob','$hospital','$department','$doctor',' $doa','$time')");
    if($res){
        echo "success";
    }
    else{
        echo "fail";
    }
}

?>
<script>
  // For Demo Purpose [Changing input group text on focus]
$(function () {
    $('input, select').on('focus', function () {
        $(this).parent().find('.input-group-text').css('border-color', '#80bdff');
    });
    $('input, select').on('blur', function () {
        $(this).parent().find('.input-group-text').css('border-color', '#ced4da');
    });
});

</script>
<style>
  
  /*
*
* ==========================================
* CUSTOM UTIL CLASSES
* ==========================================
*
*/

.border-md {
    border-width: 2px;
}

.btn-facebook {
    background: #405D9D;
    border: none;
}

.btn-facebook:hover, .btn-facebook:focus {
    background: #314879;
}

.btn-twitter {
    background: #42AEEC;
    border: none;
}

.btn-twitter:hover, .btn-twitter:focus {
    background: #1799e4;
}



/*
*
* ==========================================
* FOR DEMO PURPOSES
* ==========================================
*
*/

body {
    min-height: 100vh;
}

.form-control:not(select) {
    padding: 1.5rem 0.5rem;
}

select.form-control {
    height: 52px;
    padding-left: 0.5rem;
}

.form-control::placeholder {
    color: #ccc;
    font-weight: bold;
    font-size: 0.9rem;
}
.form-control:focus {
    box-shadow: none;
}

</style>
<script>
    $( function() {
    $( "#datepicker" ).datepicker();
  } );
</script>
		<?php
include_once'footer.php';
?>