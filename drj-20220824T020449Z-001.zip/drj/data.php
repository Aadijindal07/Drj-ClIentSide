<?php
$conn = mysqli_connect("localhost", "root", "", "doctor");
$result = mysqli_query($conn, "SELECT daysofwork,2dow,3dow FROM doctors where do_id=$doctor");
 
$data = array();
while ($row = mysqli_fetch_object($result))
{
    array_push($data, $row);
}
echo json_encode($data);
exit();
                            ?>