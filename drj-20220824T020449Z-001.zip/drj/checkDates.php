<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "doctor";

// Create connection
$db = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
 } 
$sql = "select hnaa from holidaysing";
$result = $db->query($sql);

$checkDates = array();

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $checkDates[] = $row['hnaa'];
    }
} else {
    echo "0 results";
}
echo json_encode($checkDates);
$db->close();
?>