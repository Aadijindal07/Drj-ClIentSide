<?php
include_once'header.php';
?>
    <!-- END nav -->
    
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Contact Us</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="home.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Contact <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>

<iframe src="https://www.google.com.qa/maps/d/u/0/embed?mid=1Dr9BopslOjCPw815tXiuZSQTJ5pYtD7h" width="100%" height="550" frameborder="0" style="border:0"  allowfullscreen></iframe>
		

<section class="ftco-section">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
                <div class="img align-self-stretch" style="background-image: url(images/doc-1.jpg);"></div>
              </div>
              <div class="text pt-3 text-center">
                <h3>Dr. Lloyd Wilson</h3>
                <span class="position mb-2"  style="color: #ff8002;">GOOGLE RATINGS - <b>5</b></span>
                <div class="faded">
                  <p>Appointment call: 88604 44888

Emergency Number: 011-40554055

Fax: +911126510050

IPS: 26515050, TPA: 26515050.</p>
                  <ul class="ftco-social text-center">
                    <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-google-plus"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                     <li class="ftco-animate"><a href="#"><img src="images/g.png" style="height: 16px;
    margin-bottom: 3px;">  </a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
                <div class="img align-self-stretch" style="background-image: url(images/doc-2.jpg);"></div>
              </div>
              <div class="text pt-3 text-center">
                <h3>Dr. Rachel Parker</h3>
                <span class="position mb-2" style="color: #ff8002;">Ophthalmologist</span>
                <div class="faded">
                  <p>Appointment call: 88604 44888

Emergency Number: 011-40554055

Fax: +911126510050

IPS: 26515050, TPA: 26515050..</p>
                  <ul class="ftco-social text-center">
                    <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-google-plus"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                     <li class="ftco-animate"><a href="#"><img src="images/g.png" style="height: 16px;
    margin-bottom: 3px;">  </a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
                <div class="img align-self-stretch" style="background-image: url(images/doc-3.jpg);"></div>
              </div>
              <div class="text pt-3 text-center">
                <h3>Dr. Ian Smith</h3>
                <span class="position mb-2"  style="color: #ff8002;">Dentist</span>
                <div class="faded">
                  <p>Appointment call: 88604 44888

Emergency Number: 011-40554055

Fax: +911126510050

IPS: 26515050, TPA: 26515050.</p>
                  <ul class="ftco-social text-center">
                    <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-google"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                      <li class="ftco-animate"><a href="#"><img src="images/g.png" style="height: 16px;
    margin-bottom: 3px;">  </a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 ftco-animate">
            <div class="staff">
              <div class="img-wrap d-flex align-items-stretch">
                <div class="img align-self-stretch" style="background-image: url(images/doc-4.jpg);"></div>
              </div>
              <div class="text pt-3 text-center">
                <h3>Dr. Alicia Henderson</h3>
                <span class="position mb-2"  style="color: #ff8002;">Pediatrician</span>
                <div class="faded">
                  <p>Appointment call: <B>88604 44888</B>

Emergency Number: 011-40554055

Fax: +911126510050

IPS: 26515050, TPA: 26515050.</p>
                  <ul class="ftco-social text-center">
                    <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-google-plus"></span></a></li>
                    <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
                     <li class="ftco-animate"><a href="#"><img src="images/g.png" style="height: 16px;
    margin-bottom: 3px;">  </a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

        
          
        </div>

      </div>
    </section>

  


    <?php
include_once'footer.php';
?>
    