<?php include "db_conn.php"; ?>
<!DOCTYPE html>
<html>
<head>
  <title>View</title>
  <style>

  </style>
</head>
<body>

                   <a href="index.php">&#8592;</a>
                  <form method="post">
              <input type="text" name="no">
              <input type="submit" name="sub">
              </form>   
  

     <?php 
     if (isset($_POST['sub'])) {
       $iddd=$_POST['no'];
          $sql = "SELECT * FROM report where rno ='$iddd'";
        
          $res = mysqli_query($conn,  $sql);

          if (mysqli_num_rows($res) > 0) {
            while ($images = mysqli_fetch_assoc($res)) {  
     
    ?>
<embed src="uploads/<?=$images['report_file']?>" type="application/pdf" width="100%" height="600px" />
    
    <?php }} }?>

              
                 
</body>
</html>