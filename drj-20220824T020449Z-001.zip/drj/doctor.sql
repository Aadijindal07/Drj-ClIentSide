-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2022 at 03:43 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctor`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `ano` int(250) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `gen` varchar(10) NOT NULL,
  `age` int(255) NOT NULL,
  `dob` date NOT NULL,
  `city` varchar(255) NOT NULL,
  `dep` varchar(250) NOT NULL,
  `doctor` varchar(250) NOT NULL,
  `doa` date NOT NULL,
  `tim` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`ano`, `fname`, `lname`, `email`, `phone`, `gen`, `age`, `dob`, `city`, `dep`, `doctor`, `doa`, `tim`) VALUES
(1, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '2147483647', 'mail', 12, '0000-00-00', '2', '5', '3', '0000-00-00', '1-2'),
(2, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '2147483647', 'mail', 12, '2021-05-19', '2', '5', '3', '1970-01-01', '1-2'),
(3, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '2147483647', 'mail', 12, '2021-05-24', '2', '5', '3', '1970-01-01', '1-2'),
(4, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '952616131', 'mail', 12, '2021-05-13', '2', '5', '3', '1970-01-01', '1-2'),
(5, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '2147483647', '986543221', 12, '2021-05-21', '1', '1', '1', '1970-01-01', '1-2'),
(6, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '998776655', 'mail', 12, '2021-05-20', '1', '1', '1', '1970-01-01', '1-2'),
(7, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '8360152720', 'mail', 12, '2021-05-03', '2', '5', '3', '2021-04-05', '1-2'),
(8, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '8360152720', 'mail', 12, '2021-03-01', '2', '5', '3', '2021-06-24', '1-2'),
(9, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '8360152720', 'mail', 12, '2021-03-01', '2', '5', '3', '2021-06-24', '1-2'),
(10, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '8360152720', 'mail', 12, '2021-03-01', '2', '5', '3', '2021-06-24', '1-2'),
(11, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '8360152720', 'mail', 12, '2021-03-01', '2', '5', '3', '2021-06-24', '1-2'),
(12, 'aadi', 'jindal', 'jindalaadi2742007@gmail.com', '8360152720', 'mail', 12, '2021-03-01', '2', '5', '3', '2021-06-24', '1-2');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `d_no` int(11) NOT NULL,
  `d_name` varchar(250) NOT NULL,
  `hospital` int(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`d_no`, `d_name`, `hospital`) VALUES
(1, 'cardiac', 1),
(2, 'dental', 1),
(5, 'cardiac', 2),
(6, 'dental', 2);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `do_id` int(11) NOT NULL,
  `do_name` varchar(250) NOT NULL,
  `department` varchar(250) NOT NULL,
  `holiday` varchar(250) NOT NULL,
  `starttime` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`do_id`, `do_name`, `department`, `holiday`, `starttime`) VALUES
(1, 'mr rajesh', '1', '', '1'),
(2, 'mr nath', '2', '', '2'),
(3, 'my knath', '5', '29-09-2021', '2'),
(4, 'roshan', '6', '', '1');

-- --------------------------------------------------------

--
-- Table structure for table `holiday`
--

CREATE TABLE `holiday` (
  `holiday_no` int(11) NOT NULL,
  `doctor_no` int(11) NOT NULL,
  `doh` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `holiday`
--

INSERT INTO `holiday` (`holiday_no`, `doctor_no`, `doh`) VALUES
(1, 1, '29-09-2021'),
(2, 1, '30-09-2021');

-- --------------------------------------------------------

--
-- Table structure for table `holidaysing`
--

CREATE TABLE `holidaysing` (
  `hnoo` int(11) NOT NULL,
  `hnaa` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `holidaysing`
--

INSERT INTO `holidaysing` (`hnoo`, `hnaa`) VALUES
(1, '2021-08-31'),
(2, '2021-08-30');

-- --------------------------------------------------------

--
-- Table structure for table `hospital`
--

CREATE TABLE `hospital` (
  `h_no` int(11) NOT NULL,
  `h_name` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hospital`
--

INSERT INTO `hospital` (`h_no`, `h_name`) VALUES
(1, 'mumbai'),
(2, 'delhi');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `rno` varchar(350) NOT NULL,
  `report_file` varchar(350) NOT NULL,
  `pnu` int(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`rno`, `report_file`, `pnu`) VALUES
('1', 'IMG-60a0e5b9398ca3.10050033.pdf', 0),
('2', 'IMG-60a0e7ec1c54f2.12725799.pdf', 0);

-- --------------------------------------------------------

--
-- Table structure for table `timing`
--

CREATE TABLE `timing` (
  `t_no` int(11) NOT NULL,
  `timing` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `timing`
--

INSERT INTO `timing` (`t_no`, `timing`) VALUES
(1, '1-2'),
(2, '2-3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`ano`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`d_no`),
  ADD KEY `hospital` (`hospital`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`do_id`),
  ADD KEY `department` (`department`),
  ADD KEY `starttime` (`starttime`(250));

--
-- Indexes for table `holiday`
--
ALTER TABLE `holiday`
  ADD PRIMARY KEY (`holiday_no`),
  ADD KEY `doctor no` (`doctor_no`);

--
-- Indexes for table `holidaysing`
--
ALTER TABLE `holidaysing`
  ADD PRIMARY KEY (`hnoo`);

--
-- Indexes for table `hospital`
--
ALTER TABLE `hospital`
  ADD PRIMARY KEY (`h_no`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD KEY `pnu` (`pnu`);

--
-- Indexes for table `timing`
--
ALTER TABLE `timing`
  ADD PRIMARY KEY (`t_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `ano` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `d_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `do_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `holiday`
--
ALTER TABLE `holiday`
  MODIFY `holiday_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `holidaysing`
--
ALTER TABLE `holidaysing`
  MODIFY `hnoo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `hospital`
--
ALTER TABLE `hospital`
  MODIFY `h_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `timing`
--
ALTER TABLE `timing`
  MODIFY `t_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
