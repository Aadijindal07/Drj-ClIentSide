
<?php

$db = mysqli_connect("localhost","root","","doctor");

if(!$db)
{
    die("Connection failed: " . mysqli_connect_error());
}

?>