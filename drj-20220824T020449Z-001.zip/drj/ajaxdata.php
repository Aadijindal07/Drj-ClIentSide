<?php 
include_once 'config.php';

if (isset($_POST['hospital_id'])) {
	$query = "SELECT * FROM department where hospital=".$_POST['hospital_id'];
	$result = $db->query($query);
	$hos=$_POST["hospital_id"];
	if ($result->num_rows > 0 ) {
			echo '<option value="">Select Departmet</option>';
		 while ($row = $result->fetch_assoc()) {
		 	echo '<option value='.$row['d_no'].'>'.$row['d_name'].'</option>';
		 }
	}else{

		echo '<option>No department Found!</option>';
	}

}elseif (isset($_POST['department_id'])) {
	 

	$query = "SELECT * FROM doctors where department=".$_POST['department_id'];
	$result = $db->query($query);
	$dep=$_POST['department_id'];
	if ($result->num_rows > 0 ) {
			echo '<option value="">Select doctor</option>';
		 while ($row = $result->fetch_assoc()) {
		 	echo '<option value='.$row['do_id'].'>'.$row['do_name'].'</option>';
		 }
	}else{

		echo '<option>No doctor Found!</option>';
	}

}


?>