<!DOCTYPE html>
<html>
<head>
  <title>Image Upload Using PHP</title>
  <style>
    
  </style>
</head>
<body>
  <?php if (isset($_GET['error'])): ?>
    <p><?php echo $_GET['error']; ?></p>
  <?php endif ?>
     <form action="upload.php"
           method="post"
           enctype="multipart/form-data">
<input type="text" name="rno">
           <input type="file" 
                  name="my_image">

           <input type="submit" 
                  name="submit"
                  value="Upload">
      
     </form>
</body>
</html>